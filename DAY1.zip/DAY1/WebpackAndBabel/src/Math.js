export class Point {
  constructor() {
    this.x = 100;
    this.y = 100;
  }
}

export var Add = (x, y) => {
  return x + y;
};
